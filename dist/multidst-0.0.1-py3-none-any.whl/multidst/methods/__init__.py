from .bonf import bonferroni
from .holm_bonf import holm
from .sgof import sgof_test
from .BH import bh_method
from .qval import q_value
from .BY import BY_method



