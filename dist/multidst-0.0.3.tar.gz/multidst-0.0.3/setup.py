from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()

setup(
    name='multidst',
    version='0.0.3',
    packages=find_packages(),  # Automatically find all packages and subpackages
    install_requires=[
        'numpy', 
        'pandas',
        'scipy',
        'statsmodels',
        'matplotlib'
    ],
    extras_require = {
        "dev":["twine>4.0.2"],
    },
    python_requires=">=3.10",
    long_description=description,
    long_description_content_type="text/markdown",
)

